iRibbon is a free WordPress theme designed by CyberChimps.com in California.

Theme Homepage -  http://cyberchimps.com/iribbon

Licensed under GNU General Public License v2.0 - http://www.gnu.org/licenses/gpl-2.0.html

Bootstrap is licensed under APLv2 - https://github.com/twitter/bootstrap/blob/master/LICENSE

HTML5shiv is bundled with this theme and adds HTML5 elements to browsers that are not HTML5 enabled

Dual Licensed under MIT/GPL2 - http://opensource.org/licenses/mit-license.php / GNU General Public License v2.0 - http://www.gnu.org/licenses/gpl-2.0.html

CSS3PIE is bundled with this theme and adds some CSS3 styles to ie versions Licensed under GNU General Public License v2.0 - http://www.gnu.org/licenses/gpl-2.0.html

-------------------------------------------------------------------------------------------------

For updated documentation, walkthroughs, and support please visit http://cyberchimps.com/

For updated docs please visit http://cyberchimps.com/iribbon/docs/

For the support forum please visit: http://cyberchimps.com/forum/

For more support options please visit http://cyberchimps.com/ifeaturepro/support/

-------------------------------------------------------------------------------------------------
