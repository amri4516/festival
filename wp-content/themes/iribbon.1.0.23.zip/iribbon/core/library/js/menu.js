jQuery(document).ready(function($){
		jQuery('.response-tabbed-wrap').tabs();
});

jQuery(document).ready(function($){
	$("ul").parent("li").addClass("parent"); 
});